# Osteria Fiore

## Nombre

Osteria Fiore

## Descripción

MVP universitario de la página web de un restaurante italiano ficticio ubicado en el Distrito Nacional, Santo Domingo. En esta etapa intermedia el visitante puede armar un pedido completo, elegir recoger o delivery y dejar un mensaje de contacto.

## Tecnologías

- HTML5
- CSS3
- JavaScript Vanilla
- localStorage

## Ejecución

Abrir el archivo `index.html` en un navegador. No es necesario instalar nada ni usar un servidor.

## Funcionalidades

- Todo lo incluido en la Etapa 1
- Carrito completo: aumentar, disminuir, eliminar y vaciar
- Persistencia del carrito con localStorage
- Checkout con recoger en restaurante o entrega a domicilio
- Formulario del cliente con validaciones
- Cálculo final del total
- Horarios y ubicación
- Formulario de contacto simulado
- Mensajes de error y de éxito

## Cambios

Se partió del código de la Etapa 1. Se completó el carrito, se guardó en localStorage, se agregó el flujo de pedido con validaciones y se incorporaron horarios, ubicación y contacto.
